package com.localsmb.music;

import android.net.Uri;
import androidx.media3.common.C;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.BaseDataSource;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import java.io.IOException;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbRandomAccessFile;

@UnstableApi
final class SmbDataSource extends BaseDataSource {
    private final SmbClient client;
    private Uri uri;
    private SmbFile smbFile;
    private SmbRandomAccessFile random;
    private long bytesRemaining;
    private boolean opened;

    SmbDataSource(SmbClient client) {
        super(true);
        this.client = client;
    }

    @Override public long open(DataSpec spec) throws IOException {
        transferInitializing(spec);
        try {
            uri = spec.uri;
            smbFile = new SmbFile(spec.uri.toString(), client.context);
            long size = smbFile.length();
            if (spec.position > size) throw new IOException("播放偏移超过文件长度");
            random = new SmbRandomAccessFile(smbFile, "r");
            random.seek(spec.position);
            long available = size - spec.position;
            bytesRemaining = spec.length == C.LENGTH_UNSET ? available : Math.min(available, spec.length);
            opened = true;
            transferStarted(spec);
            return bytesRemaining;
        } catch (Exception e) {
            try { close(); } catch (Exception ignored) { }
            throw new IOException("SMB 音乐读取失败：" + e.getMessage(), e);
        }
    }

    @Override public int read(byte[] buffer, int offset, int length) throws IOException {
        if (length == 0) return 0;
        if (bytesRemaining == 0) return C.RESULT_END_OF_INPUT;
        try {
            int count = random.read(buffer, offset, (int)Math.min(bytesRemaining, length));
            if (count < 0) return C.RESULT_END_OF_INPUT;
            bytesRemaining -= count;
            bytesTransferred(count);
            return count;
        } catch (Exception e) {
            throw new IOException("SMB 读取中断：" + e.getMessage(), e);
        }
    }

    @Override public Uri getUri() { return uri; }

    @Override public void close() throws IOException {
        try {
            if (random != null) { random.close(); random = null; }
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            if (smbFile != null) { try { smbFile.close(); } catch (Exception ignored) {} smbFile = null; }
            uri = null;
            if (opened) { opened = false; transferEnded(); }
        }
    }

    static final class Factory implements DataSource.Factory {
        private final SmbClient client;
        Factory(SmbClient client) { this.client = client; }
        @Override public DataSource createDataSource() { return new SmbDataSource(client); }
    }
}
