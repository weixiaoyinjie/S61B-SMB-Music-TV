package com.localsmb.music;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecurePrefs {
    private static final String KEY_ALIAS = "S61B_SMB_LOCAL_CREDENTIALS_v1";
    private final SharedPreferences prefs;
    SecurePrefs(Context context) { prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE); }
    String path() { return prefs.getString("path", ""); }
    String username() { return prefs.getString("user", ""); }
    int preset() { return prefs.getInt("preset", 0); }
    void preset(int p) { prefs.edit().putInt("preset", p).apply(); }
    void save(String path, String username, String password) {
        SharedPreferences.Editor editor = prefs.edit().putString("path", path).putString("user", username);
        try {
            SecretKey key = key();
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key);
            byte[] encrypted = c.doFinal(password.getBytes(StandardCharsets.UTF_8));
            editor.putString("password", Base64.encodeToString(encrypted, Base64.NO_WRAP));
            editor.putString("iv", Base64.encodeToString(c.getIV(), Base64.NO_WRAP));
        } catch (Exception e) {
            // Never persist plaintext; reconnect will require re-entry if Keystore fails.
            editor.remove("password").remove("iv");
        }
        editor.apply();
    }
    String password() {
        String ct = prefs.getString("password", "");
        String iv = prefs.getString("iv", "");
        if (ct.isEmpty() || iv.isEmpty()) return "";
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(ct, Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }
    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEY_ALIAS)) return (SecretKey) store.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return generator.generateKey();
    }
}
