package com.localsmb.music;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;

final class SmbClient {
    static final class Entry {
        final String name, url;
        final boolean folder;
        Entry(String name, String url, boolean folder) {
            this.name = name; this.url = url; this.folder = folder;
        }
    }
    static final class Listing {
        final List<Entry> items;
        final List<Track> tracks;
        final String coverUrl;
        Listing(List<Entry> items, List<Track> tracks, String coverUrl) {
            this.items = items; this.tracks = tracks; this.coverUrl = coverUrl;
        }
    }

    final CIFSContext context;

    SmbClient(String username, String password) throws Exception {
        Properties props = new Properties();
        // Router USB sharing typically supports SMB2/SMB3; SMB1 disabled intentionally.
        props.setProperty("jcifs.smb.client.minVersion", "SMB202");
        props.setProperty("jcifs.smb.client.maxVersion", "SMB311");
        props.setProperty("jcifs.smb.client.responseTimeout", "20000");
        props.setProperty("jcifs.smb.client.soTimeout", "30000");
        props.setProperty("jcifs.smb.lmCompatibility", "3");
        CIFSContext base = new BaseContext(new PropertyConfiguration(props));
        if (username == null || username.trim().isEmpty()) {
            context = base.withGuestCrendentials();
        } else {
            String domain = "";
            String user = username.trim();
            int i = user.indexOf('\\');
            if (i > 0) { domain = user.substring(0, i); user = user.substring(i + 1); }
            context = base.withCredentials(new NtlmPasswordAuthenticator(domain, user, password == null ? "" : password));
        }
    }

    static String normalize(String raw) {
        String input = raw.trim().replace('\\', '/');
        if (!input.toLowerCase(Locale.ROOT).startsWith("smb://")) input = "smb://" + input;
        if (!input.endsWith("/")) input += "/";
        if (!input.matches("(?i)^smb://[^/]+/[^/]+/.*$")) {
            throw new IllegalArgumentException("地址必须包含共享名，例如 smb://192.168.0.1/USB/");
        }
        return input.replace(" ", "%20");
    }

    Listing list(String path) throws Exception {
        List<Entry> items = new ArrayList<>();
        List<Track> tracks = new ArrayList<>();
        String cover = null;
        try (SmbFile folder = new SmbFile(path, context)) {
            if (!folder.isDirectory()) throw new IOException("不是文件夹：" + path);
            for (SmbFile item : folder.listFiles()) {
                try (SmbFile child = item) {
                    String name = child.getName();
                    if (name.endsWith("/")) name = name.substring(0, name.length() - 1);
                    if (name.startsWith(".")) continue;
                    boolean isFolder = child.isDirectory();
                    String url = child.getCanonicalPath();
                    if (isFolder) {
                        items.add(new Entry(name, url, true));
                    } else if (isAudio(name)) {
                        items.add(new Entry(name, url, false));
                        tracks.add(new Track(removeExtension(name), url));
                    } else if (isCover(name)) {
                        if (cover == null || name.toLowerCase(Locale.ROOT).startsWith("folder.")) cover = url;
                    }
                }
            }
        }
        items.sort(Comparator.comparing((Entry e) -> !e.folder).thenComparing(e -> e.name.toLowerCase(Locale.ROOT)));
        tracks.sort(Comparator.comparing(t -> t.title.toLowerCase(Locale.ROOT)));
        return new Listing(items, tracks, cover);
    }

    Bitmap loadCover(String path) throws Exception {
        if (path == null) return null;
        try (SmbFile file = new SmbFile(path, context); InputStream stream = file.getInputStream()) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            options.inSampleSize = 2;
            return BitmapFactory.decodeStream(stream, null, options);
        }
    }

    static boolean isAudio(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String ext : new String[]{".mp3", ".flac", ".m4a", ".aac", ".wav", ".ogg", ".opus"}) {
            if (n.endsWith(ext)) return true;
        }
        return false;
    }
    private static boolean isCover(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.equals("folder.jpg") || n.equals("folder.png") || n.equals("cover.jpg") || n.equals("cover.png") || n.equals("album.jpg") || n.equals("album.png");
    }
    static String removeExtension(String name) {
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }
}
