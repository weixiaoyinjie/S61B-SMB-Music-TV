package com.localsmb.music;

final class Track {
    final String title;
    final String url;
    Track(String title, String url) {
        this.title = title;
        this.url = url;
    }
}
