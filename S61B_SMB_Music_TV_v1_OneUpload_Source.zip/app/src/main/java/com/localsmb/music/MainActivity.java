package com.localsmb.music;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.AudioManager;
import android.media.audiofx.Equalizer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 16, 29);
    private static final int PANEL = Color.rgb(22, 30, 47);
    private static final int TEXT = Color.rgb(237, 243, 250);
    private static final int MUTED = Color.rgb(159, 178, 202);
    private static final int ACCENT = Color.rgb(75, 220, 205);
    private static final String[] PRESETS = {
            "原音 · EQ关闭", "均衡 Hi-Fi", "人声增强", "W510 低频收敛", "夜间柔和"
    };

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int generation = 0;
    private SecurePrefs prefs;
    private SmbClient client;
    private ExoPlayer player;
    private Equalizer equalizer;
    private int eqSession = C.AUDIO_SESSION_ID_UNSET;
    private int preset = 0;
    private String rootPath = "";
    private String currentPath = "";
    private String lastCoverUrl = null;
    private final List<Track> playing = new ArrayList<>();
    private List<Track> folderTracks = new ArrayList<>();

    private TextView titleStatus;
    private TextView breadcrumb;
    private LinearLayout folderList;
    private LinearLayout queueList;
    private TextView nowTitle;
    private TextView nowSecondary;
    private TextView playPause;
    private TextView shuffleButton;
    private TextView repeatButton;
    private TextView eqButton;
    private TextView eqStatus;
    private TextView timeLabel;
    private TextView folderStatus;
    private ImageView coverImage;
    private TextView coverFallback;
    private SeekBar seek;
    private boolean userSeeking;
    private boolean shuffle;
    private int lastDisplayedTrack = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs = new SecurePrefs(this);
        preset = prefs.preset();
        buildUi();
        ui.postDelayed(progressTick, 700);
        if (!prefs.path().isEmpty()) {
            connect(prefs.path(), prefs.username(), prefs.password());
        } else {
            titleStatus.setText("先设置局域网 SMB 音乐共享地址");
            openSettings();
        }
    }

    private void buildUi() {
        LinearLayout root = vbox(); root.setPadding(dp(24), dp(16), dp(24), dp(16)); root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout header = hbox(); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text("S61B  /  SMB MUSIC", 25, TEXT, true);
        header.addView(name, new LinearLayout.LayoutParams(0, dp(54), 1));
        TextView settings = button("⚙  SMB 设置", () -> openSettings());
        header.addView(settings, new LinearLayout.LayoutParams(dp(170), dp(48)));
        header.addView(space(10, 1));
        TextView sound = button("♫  音响建议", this::showSoundbarGuide);
        header.addView(sound, new LinearLayout.LayoutParams(dp(170), dp(48)));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(55)));

        titleStatus = text("连接准备中…", 14, MUTED, false);
        root.addView(titleStatus, new LinearLayout.LayoutParams(-1, dp(29)));

        LinearLayout content = hbox(); content.setPadding(0, dp(6), 0, 0);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout left = panel();
        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, -1, 1.06f);
        leftLp.setMargins(0, 0, dp(10), 0);
        content.addView(left, leftLp);
        LinearLayout right = panel();
        content.addView(right, new LinearLayout.LayoutParams(0, -1, 1));

        TextView listHead = text("音乐文件夹", 22, TEXT, true);
        left.addView(listHead, new LinearLayout.LayoutParams(-1, dp(40)));
        breadcrumb = text("尚未连接 SMB", 13, MUTED, false);
        breadcrumb.setSingleLine(true); breadcrumb.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        left.addView(breadcrumb, new LinearLayout.LayoutParams(-1, dp(30)));

        LinearLayout nav = hbox();
        nav.addView(button("← 上一级", this::goUp), new LinearLayout.LayoutParams(0, dp(44), 1));
        nav.addView(space(8, 1));
        nav.addView(button("↻ 重新扫描", () -> browse(currentPath, false)), new LinearLayout.LayoutParams(0, dp(44), 1));
        left.addView(nav, new LinearLayout.LayoutParams(-1, dp(46)));
        left.addView(space(1, 10));
        ScrollView folderScroll = new ScrollView(this);
        folderScroll.setFillViewport(true);
        folderList = vbox(); folderList.setFocusable(false);
        folderScroll.addView(folderList, new ScrollView.LayoutParams(-1, -2));
        left.addView(folderScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        folderStatus = text("选择包含音乐的文件夹，将立即连续播放其中的歌曲", 12, MUTED, false);
        left.addView(folderStatus, new LinearLayout.LayoutParams(-1, dp(31)));

        LinearLayout playingHead = hbox(); playingHead.setGravity(Gravity.CENTER_VERTICAL);
        coverImage = new ImageView(this); coverImage.setBackground(shape(Color.rgb(34, 45, 67), 15, 0));
        coverImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        playingHead.addView(coverImage, new LinearLayout.LayoutParams(dp(112), dp(112)));
        coverFallback = text("♫", 65, ACCENT, true);
        coverFallback.setGravity(Gravity.CENTER);
        // The note is shown until a folder image exists.
        android.widget.FrameLayout artFrame = new android.widget.FrameLayout(this);
        playingHead.removeView(coverImage);
        artFrame.addView(coverImage, new android.widget.FrameLayout.LayoutParams(-1, -1));
        artFrame.addView(coverFallback, new android.widget.FrameLayout.LayoutParams(-1, -1));
        playingHead.addView(artFrame, new LinearLayout.LayoutParams(dp(112), dp(112)));
        LinearLayout trackInfo = vbox(); trackInfo.setPadding(dp(15), dp(5), 0, 0);
        trackInfo.addView(text("正在播放", 13, ACCENT, true));
        nowTitle = text("尚未播放音乐", 21, TEXT, true);
        nowTitle.setMaxLines(2); nowTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        trackInfo.addView(nowTitle, new LinearLayout.LayoutParams(-1, dp(66)));
        nowSecondary = text("从左侧选择文件夹或歌曲", 13, MUTED, false);
        trackInfo.addView(nowSecondary);
        playingHead.addView(trackInfo, new LinearLayout.LayoutParams(0, -1, 1));
        right.addView(playingHead, new LinearLayout.LayoutParams(-1, dp(117)));
        right.addView(space(1, 5));

        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar s) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                if (player != null && player.getDuration() > 0)
                    player.seekTo((long)((s.getProgress() / 1000d) * player.getDuration()));
                userSeeking = false;
            }
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && player != null && player.getDuration() > 0)
                    timeLabel.setText(formatMs((long)(p / 1000d * player.getDuration())) + " / " + formatMs(player.getDuration()));
            }
        });
        right.addView(seek, new LinearLayout.LayoutParams(-1, dp(29)));
        timeLabel = text("00:00 / 00:00", 13, MUTED, false); timeLabel.setGravity(Gravity.RIGHT);
        right.addView(timeLabel, new LinearLayout.LayoutParams(-1, dp(20)));

        LinearLayout ctrls = hbox(); ctrls.setGravity(Gravity.CENTER_VERTICAL);
        ctrls.addView(button("|◀", () -> { if (player != null) player.seekToPreviousMediaItem(); }), new LinearLayout.LayoutParams(0, dp(47), 1));
        ctrls.addView(space(9, 1));
        playPause = button("▶ 播放", this::togglePlayback);
        ctrls.addView(playPause, new LinearLayout.LayoutParams(0, dp(47), 1.4f));
        ctrls.addView(space(9, 1));
        ctrls.addView(button("▶|", () -> { if (player != null) player.seekToNextMediaItem(); }), new LinearLayout.LayoutParams(0, dp(47), 1));
        ctrls.addView(space(9, 1));
        ctrls.addView(button("-10s", () -> { if (player != null) player.seekBack(); }), new LinearLayout.LayoutParams(0, dp(47), .85f));
        ctrls.addView(space(9, 1));
        ctrls.addView(button("+10s", () -> { if (player != null) player.seekForward(); }), new LinearLayout.LayoutParams(0, dp(47), .85f));
        right.addView(ctrls, new LinearLayout.LayoutParams(-1, dp(51)));
        right.addView(space(1, 5));

        LinearLayout modes = hbox();
        shuffleButton = button("随机：关", () -> { shuffle = !shuffle; if (player != null) player.setShuffleModeEnabled(shuffle); refreshModes(); });
        repeatButton = button("循环：全部", () -> {
            if (player != null) {
                int m = player.getRepeatMode();
                player.setRepeatMode(m == Player.REPEAT_MODE_ALL ? Player.REPEAT_MODE_ONE : m == Player.REPEAT_MODE_ONE ? Player.REPEAT_MODE_OFF : Player.REPEAT_MODE_ALL);
            }
            refreshModes();
        });
        modes.addView(shuffleButton, new LinearLayout.LayoutParams(0, dp(39), 1));
        modes.addView(space(8, 1));
        modes.addView(repeatButton, new LinearLayout.LayoutParams(0, dp(39), 1));
        modes.addView(space(8, 1));
        modes.addView(button("音量 −", () -> volume(false)), new LinearLayout.LayoutParams(0, dp(39), 1));
        modes.addView(space(8, 1));
        modes.addView(button("音量 +", () -> volume(true)), new LinearLayout.LayoutParams(0, dp(39), 1));
        right.addView(modes, new LinearLayout.LayoutParams(-1, dp(42)));
        right.addView(space(1, 5));

        LinearLayout eqBar = hbox(); eqBar.setGravity(Gravity.CENTER_VERTICAL);
        eqButton = button("音效：" + PRESETS[preset], this::choosePreset);
        eqBar.addView(eqButton, new LinearLayout.LayoutParams(0, dp(43), 1));
        eqBar.addView(space(10, 1));
        eqStatus = text("原音输出", 12, MUTED, false);
        eqBar.addView(eqStatus, new LinearLayout.LayoutParams(dp(166), -2));
        right.addView(eqBar, new LinearLayout.LayoutParams(-1, dp(46)));
        TextView advice = text("S61B 建议：Music 模式 · W510 先设 0 · 音响本体需用遥控器/SmartThings 调节", 12, MUTED, false);
        right.addView(advice, new LinearLayout.LayoutParams(-1, dp(31)));
        right.addView(text("当前播放列表", 17, TEXT, true), new LinearLayout.LayoutParams(-1, dp(29)));
        ScrollView queueScroll = new ScrollView(this);
        queueList = vbox(); queueScroll.addView(queueList, new ScrollView.LayoutParams(-1, -2));
        right.addView(queueScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        refreshModes();
    }

    private void connect(String url, String username, String password) {
        try {
            String normalized = SmbClient.normalize(url);
            generation++;
            rootPath = normalized;
            currentPath = normalized;
            client = new SmbClient(username, password);
            if (player != null) { player.release(); player = null; }
            releaseEqualizer();
            playing.clear(); folderTracks.clear();
            queueList.removeAllViews();
            lastDisplayedTrack = -1;
            DataSource.Factory source = new SmbDataSource.Factory(client);
            player = new ExoPlayer.Builder(this)
                    .setMediaSourceFactory(new DefaultMediaSourceFactory(source))
                    .build();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true);
            player.setSeekBackIncrementMs(10000);
            player.setSeekForwardIncrementMs(10000);
            player.setRepeatMode(Player.REPEAT_MODE_ALL);
            player.addListener(new Player.Listener() {
                @Override public void onIsPlayingChanged(boolean isPlaying) { updatePlayback(); }
                @Override public void onMediaItemTransition(MediaItem mediaItem, int reason) { updatePlayback(); rebuildQueue(); }
                @Override public void onPlaybackStateChanged(int state) { updatePlayback(); }
                @Override public void onPlayerError(PlaybackException error) {
                    titleStatus.setText("播放失败：" + concise(error));
                    toast("播放失败：检查 SMB 共享和音频格式");
                }
            });
            prefs.save(normalized, username, password);
            titleStatus.setText("正在连接 SMB 共享：" + normalized);
            browse(normalized, false);
        } catch (Exception e) {
            titleStatus.setText("连接设置无效：" + concise(e));
            toast(concise(e));
        }
    }

    private void browse(String path, boolean autoPlay) {
        if (client == null || path == null || path.isEmpty()) return;
        final int request = ++generation;
        final SmbClient currentClient = client;
        currentPath = path;
        breadcrumb.setText(path);
        folderStatus.setText("正在扫描文件夹…");
        folderList.removeAllViews();
        folderList.addView(text("正在读取 SMB 音乐文件…", 16, MUTED, false));
        io.execute(() -> {
            try {
                SmbClient.Listing listing = currentClient.list(path);
                ui.post(() -> {
                    if (request != generation) return;
                    folderTracks = listing.tracks;
                    displayListing(listing);
                    if (autoPlay && !listing.tracks.isEmpty()) startQueue(listing.tracks, 0, listing.coverUrl);
                    else if (autoPlay) titleStatus.setText("已打开文件夹；当前目录无直接可播放的音乐，请进入子文件夹");
                });
            } catch (Exception e) {
                String msg = concise(e);
                ui.post(() -> {
                    if (request != generation) return;
                    folderList.removeAllViews();
                    folderList.addView(text("读取失败：" + msg, 15, Color.rgb(255, 160, 150), false));
                    folderStatus.setText("确认 IP、共享文件夹名、用户名/密码，以及路由器 SMB2/3 状态");
                    titleStatus.setText("SMB 连接失败：" + msg);
                });
            }
        });
    }

    private void displayListing(SmbClient.Listing listing) {
        folderList.removeAllViews();
        int folders = 0;
        for (SmbClient.Entry e : listing.items) if (e.folder) folders++;
        folderStatus.setText("找到 " + folders + " 个文件夹、" + listing.tracks.size() + " 首音乐 · 选择文件夹自动播放");
        titleStatus.setText("已连接 · SMB2/SMB3 · " + currentPath);
        if (listing.items.isEmpty()) folderList.addView(text("文件夹为空，或没有受支持的音乐格式", 16, MUTED, false));
        int displayed = 0;
        for (SmbClient.Entry e : listing.items) {
            if (displayed++ >= 450) break;
            TextView item = button((e.folder ? "▣  " : "♫  ") + e.name, () -> {
                if (e.folder) browse(e.url, true);
                else {
                    int idx = 0;
                    for (int i = 0; i < folderTracks.size(); i++) if (folderTracks.get(i).url.equals(e.url)) { idx = i; break; }
                    startQueue(folderTracks, idx, listing.coverUrl);
                }
            });
            item.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            item.setSingleLine(true);
            item.setEllipsize(android.text.TextUtils.TruncateAt.END);
            item.setPadding(dp(17), 0, dp(8), 0);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52));
            p.setMargins(0, 0, 0, dp(5));
            folderList.addView(item, p);
        }
        if (listing.items.size() > 450) folderList.addView(text("仅显示前 450 项；建议按专辑建立子文件夹", 13, MUTED, false));
    }

    private void startQueue(List<Track> tracks, int startIndex, String coverUrl) {
        if (player == null || tracks == null || tracks.isEmpty()) return;
        playing.clear(); playing.addAll(tracks);
        List<MediaItem> queue = new ArrayList<>(tracks.size());
        for (Track track : tracks) {
            queue.add(new MediaItem.Builder().setUri(track.url)
                    .setMediaMetadata(new MediaMetadata.Builder().setTitle(track.title).build())
                    .build());
        }
        player.setMediaItems(queue, Math.min(Math.max(startIndex, 0), tracks.size() - 1), 0);
        player.setShuffleModeEnabled(shuffle);
        player.prepare();
        player.play();
        updatePlayback();
        rebuildQueue();
        showCover(coverUrl);
    }

    private void showCover(String coverUrl) {
        lastCoverUrl = coverUrl;
        if (coverUrl == null || client == null) {
            coverImage.setImageDrawable(null);
            coverFallback.setVisibility(View.VISIBLE);
            return;
        }
        final SmbClient currentClient = client;
        io.execute(() -> {
            try {
                Bitmap art = currentClient.loadCover(coverUrl);
                ui.post(() -> {
                    if (!coverUrl.equals(lastCoverUrl) || client != currentClient) return;
                    coverImage.setImageBitmap(art);
                    coverFallback.setVisibility(art == null ? View.VISIBLE : View.GONE);
                });
            } catch (Exception ignored) {
                ui.post(() -> { if (coverUrl.equals(lastCoverUrl)) coverFallback.setVisibility(View.VISIBLE); });
            }
        });
    }

    private void rebuildQueue() {
        queueList.removeAllViews();
        if (playing.isEmpty()) {
            queueList.addView(text("播放列表为空", 14, MUTED, false)); return;
        }
        int index = player == null ? -1 : player.getCurrentMediaItemIndex();
        int display = Math.min(playing.size(), 250);
        for (int i = 0; i < display; i++) {
            final int at = i;
            TextView t = button((i == index ? "▶  " : String.format(Locale.ROOT, "%02d  ", i + 1)) + playing.get(i).title,
                    () -> { if (player != null) { player.seekToDefaultPosition(at); player.play(); } });
            if (i == index) t.setTextColor(ACCENT);
            t.setTextSize(14); t.setSingleLine(true);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(41));
            lp.setMargins(0, 0, 0, dp(3));
            queueList.addView(t, lp);
        }
        if (playing.size() > display) queueList.addView(text("列表较长，仅展示前 " + display + " 首（仍会播放全部歌曲）", 12, MUTED, false));
    }

    private void updatePlayback() {
        if (player == null) return;
        int i = player.getCurrentMediaItemIndex();
        if (i >= 0 && i < playing.size()) {
            nowTitle.setText(playing.get(i).title);
            nowSecondary.setText("第 " + (i + 1) + " / " + playing.size() + " 首  ·  SMB 网络播放");
        }
        playPause.setText(player.isPlaying() ? "Ⅱ 暂停" : "▶ 播放");
    }

    private void refreshModes() {
        shuffleButton.setText("随机：" + (shuffle ? "开" : "关"));
        int repeat = player == null ? Player.REPEAT_MODE_ALL : player.getRepeatMode();
        repeatButton.setText(repeat == Player.REPEAT_MODE_ALL ? "循环：全部" : repeat == Player.REPEAT_MODE_ONE ? "循环：单曲" : "循环：关闭");
    }

    private void choosePreset() {
        new AlertDialog.Builder(this)
            .setTitle("播放器音效预设（仅尝试处理本 App 的 PCM 音频）")
            .setSingleChoiceItems(PRESETS, preset, (dialog, selected) -> {
                preset = selected;
                prefs.preset(selected);
                eqButton.setText("音效：" + PRESETS[preset]);
                applyEqualizer();
                dialog.dismiss();
            })
            .setNeutralButton("S61B/W510 设置说明", (dialog, which) -> showSoundbarGuide())
            .setNegativeButton("取消", null)
            .show();
    }

    private void applyEqualizer() {
        if (preset == 0) {
            if (equalizer != null) { try { equalizer.setEnabled(false); } catch (Exception ignored) {} }
            eqStatus.setText("原音：不加 DSP");
            return;
        }
        if (player == null) { eqStatus.setText("尚未开始播放"); return; }
        int session = player.getAudioSessionId();
        if (session == C.AUDIO_SESSION_ID_UNSET) { eqStatus.setText("等待音频会话"); return; }
        try {
            if (equalizer == null || eqSession != session) {
                releaseEqualizer();
                equalizer = new Equalizer(0, session);
                eqSession = session;
            }
            short[] range = equalizer.getBandLevelRange();
            for (short b = 0; b < equalizer.getNumberOfBands(); b++) {
                // Use each platform band's center frequency; levels are in millibels.
                float hz = equalizer.getCenterFreq(b) / 1000f;
                float db = gainDb(preset, hz);
                short millibel = (short)Math.max(range[0], Math.min(range[1], Math.round(db * 100)));
                equalizer.setBandLevel(b, millibel);
            }
            equalizer.setEnabled(true);
            eqStatus.setText("EQ 已尝试启用");
        } catch (Exception e) {
            releaseEqualizer();
            eqStatus.setText("该输出不支持 EQ");
        }
    }

    private static float gainDb(int index, float hz) {
        float[] freqs = {70, 250, 1000, 4000, 12000};
        float[][] sets = {
                {0, 0, 0, 0, 0},
                {0, -.5f, 0, .6f, .5f},
                {-.7f, -.4f, .7f, 1.2f, .2f},
                {-1.5f, -1f, 0, .4f, .1f},
                {-.8f, -.3f, 0, -.8f, -1.1f}
        };
        if (hz <= freqs[0]) return sets[index][0];
        for (int i = 1; i < freqs.length; i++) {
            if (hz <= freqs[i]) {
                float ratio = (float)(Math.log(hz/freqs[i-1]) / Math.log(freqs[i]/freqs[i-1]));
                return sets[index][i-1] + ratio * (sets[index][i]-sets[index][i-1]);
            }
        }
        return sets[index][4];
    }

    private void releaseEqualizer() {
        if (equalizer != null) {
            try { equalizer.setEnabled(false); equalizer.release(); } catch (Exception ignored) {}
            equalizer = null;
        }
        eqSession = C.AUDIO_SESSION_ID_UNSET;
    }

    private final Runnable progressTick = new Runnable() {
        @Override public void run() {
            if (player != null) {
                long position = Math.max(0, player.getCurrentPosition());
                long duration = player.getDuration();
                if (duration == C.TIME_UNSET || duration < 0) duration = 0;
                if (!userSeeking) {
                    seek.setProgress(duration > 0 ? (int)Math.min(1000, position * 1000L / duration) : 0);
                    timeLabel.setText(formatMs(position) + " / " + formatMs(duration));
                }
                if (player.getAudioSessionId() != eqSession && preset != 0) applyEqualizer();
                int i = player.getCurrentMediaItemIndex();
                if (i != lastDisplayedTrack && !playing.isEmpty()) { lastDisplayedTrack = i; updatePlayback(); }
            }
            ui.postDelayed(this, 900);
        }
    };

    private void openSettings() {
        LinearLayout form = vbox(); form.setPadding(dp(22), dp(8), dp(22), 0);
        EditText uri = edit("SMB 地址，例如 smb://192.168.0.1/USB/Music/", prefs.path());
        EditText user = edit("共享用户名（guest 留空）", prefs.username());
        EditText pass = edit("密码（可留空）", prefs.password());
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(text("共享文件夹路径（必须包含共享名）", 13, MUTED, false));
        form.addView(uri, new LinearLayout.LayoutParams(-1, dp(46)));
        form.addView(text("SMB 用户名", 13, MUTED, false));
        form.addView(user, new LinearLayout.LayoutParams(-1, dp(46)));
        form.addView(text("SMB 密码", 13, MUTED, false));
        form.addView(pass, new LinearLayout.LayoutParams(-1, dp(46)));
        new AlertDialog.Builder(this)
                .setTitle("连接路由器 / NAS / USB 硬盘")
                .setView(form)
                .setPositiveButton("连接 SMB", (d, w) -> connect(uri.getText().toString(), user.getText().toString(), pass.getText().toString()))
                .setNegativeButton("取消", null)
                .show();
    }

    private void showSoundbarGuide() {
        String message = "推荐基准（请在 S61B 遥控器或 SmartThings 中设置）：\n\n"
                + "① Sound Mode：Music（更适合普通立体声音乐）\n"
                + "② SWA-W510：低音炮等级先设 0；低频轰头可尝试 -2\n"
                + "③ Bass / Treble：先设 0，不要双重增强\n"
                + "④ FLAC / 无损：先选本 App『原音 · EQ关闭』\n"
                + "⑤ 人声不清楚：可试听『人声增强』，但只有电视音频引擎支持 EQ 时才有效\n\n"
                + "注意：这些是听音起点，不是实测校准值。本 App 无法直接修改 S61B/W510 的内部音效、HDMI ARC 或 Atmos 设置；音效 EQ 也不保证通过所有 HDMI 输出生效。";
        new AlertDialog.Builder(this).setTitle("S61B + W510 音效优化指引").setMessage(message).setPositiveButton("知道了", null).show();
    }

    private void goUp() {
        if (currentPath == null || currentPath.isEmpty() || currentPath.equals(rootPath)) return;
        String p = currentPath;
        if (p.endsWith("/")) p = p.substring(0, p.length() - 1);
        int last = p.lastIndexOf('/');
        if (last >= 0) p = p.substring(0, last + 1);
        if (p.length() < rootPath.length() || !p.startsWith(rootPath)) p = rootPath;
        browse(p, false);
    }

    @Override public void onBackPressed() {
        if (!currentPath.equals(rootPath)) goUp();
        else super.onBackPressed();
    }

    @Override public boolean onKeyDown(int code, KeyEvent event) {
        if (player != null) {
            if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY || code == KeyEvent.KEYCODE_MEDIA_PAUSE) { togglePlayback(); return true; }
            if (code == KeyEvent.KEYCODE_MEDIA_NEXT) { player.seekToNextMediaItem(); return true; }
            if (code == KeyEvent.KEYCODE_MEDIA_PREVIOUS) { player.seekToPreviousMediaItem(); return true; }
        }
        return super.onKeyDown(code, event);
    }

    private void togglePlayback() {
        if (player == null) return;
        if (player.isPlaying()) player.pause();
        else if (player.getMediaItemCount() > 0) player.play();
        updatePlayback();
    }

    private void volume(boolean plus) {
        AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, plus ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
    }

    private static String formatMs(long milliseconds) {
        long seconds = Math.max(0, milliseconds / 1000);
        return String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60);
    }
    private static String concise(Throwable error) {
        Throwable t = error;
        while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        return t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
    }
    private void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    private int dp(int value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private LinearLayout vbox() { LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); return box; }
    private LinearLayout hbox() { LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); return box; }
    private View space(int w, int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), dp(h))); return v; }
    private LinearLayout panel() {
        LinearLayout box = vbox(); box.setPadding(dp(18), dp(17), dp(18), dp(14));
        box.setBackground(shape(PANEL, 17, 0)); return box;
    }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private EditText edit(String hint, String initial) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(TEXT);
        e.setHint(hint); e.setText(initial == null ? "" : initial);
        e.setSelectAllOnFocus(true);
        return e;
    }
    private static GradientDrawable shape(int color, float radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke > 0) d.setStroke(stroke, ACCENT);
        return d;
    }
    private TextView button(String text, Runnable action) {
        TextView b = text(text, 15, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(7), dp(4), dp(7), dp(4));
        b.setFocusable(true); b.setFocusableInTouchMode(false); b.setClickable(true);
        StateListDrawable drawable = new StateListDrawable();
        drawable.addState(new int[]{android.R.attr.state_focused}, shape(Color.rgb(32, 83, 85), dp(10), dp(2)));
        drawable.addState(new int[]{android.R.attr.state_pressed}, shape(Color.rgb(32, 83, 85), dp(10), dp(2)));
        drawable.addState(new int[]{}, shape(Color.rgb(38, 49, 70), dp(10), 0));
        b.setBackground(drawable);
        b.setOnClickListener(v -> action.run());
        b.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? 1.018f : 1f).scaleY(focused ? 1.018f : 1f).setDuration(100).start();
        });
        return b;
    }

    @Override protected void onDestroy() {
        generation++;
        ui.removeCallbacks(progressTick);
        releaseEqualizer();
        if (player != null) { player.release(); player = null; }
        io.shutdownNow();
        super.onDestroy();
    }
}
