# S61B SMB Music TV v1.0

独立的 Google TV Android App：从路由器 / NAS 的 SMB2/3 共享文件夹直接流式播放音乐，**不依赖 Kodi 或 Vimu**。

## 当前实现

- 支持 SMB2/SMB3 共享：IP、共享名、用户名、密码（可使用 Guest，需服务器允许）；使用 NTLMv2
- 遥控器方向键选择文件夹：进入含音乐的文件夹后，**自动将该目录内的歌曲加入队列并播放**
- 手动选歌、上一首/下一首、播放/暂停、快退/快进 10 秒、SeekBar、单曲/列表循环、随机、系统音量
- 音乐格式：MP3、FLAC、M4A、AAC、WAV、OGG、OPUS（受 Google TV 内部解码器支持范围限制，不承诺所有编码都能播放）
- 读取 `folder.jpg`、`folder.png`、`cover.jpg`、`cover.png`、`album.jpg`、`album.png` 文件夹封面
- 内建 5 个播放器 EQ 预设；**只有 Android 音频输出支持平台 Equalizer 时才可能生效**，不保证 HDMI ARC / 数字传输的实际效果
- S61B + W510 手动音效设置建议界面（不通过未授权协议控制三星设备）
- SMB 凭据使用 Android Keystore AES-GCM 加密保存在设备上；Keystore 不可用时不明文保存密码

## 首次连接

1. 将 Google TV 与路由器 SMB 硬盘连接至同一局域网。
2. 开启 App，点击「SMB 设置」。
3. 输入准确共享路径（**不是路由器设置页**），例如：`smb://192.168.0.1/USB/Music/` 或 `smb://192.168.0.1/USB/`。
4. 根据路由器 SMB 设置填写账号密码。如允许 Guest，用户名留空。
5. 成功后选择含歌曲的文件夹，直接自动播放。点击某一首可从该首开始连续播放。
6. 如文件夹里只有其他文件夹，需要继续点进包含歌曲的目录；v1 暂不递归扫描所有子文件夹。

## S61B / W510 建议

建议先设：**S61B 音乐 Music 模式 + W510 0 + Bass 0 + Treble 0 + App「原音」**。
如低频听感轰头，可在 S61B 的低音炮调节中尝试 W510 -2。设备上各 Sound Mode、低音炮音量通过原机遥控器或官方 SmartThings 调节。

本播放器无法直接修改三星 soundbar 原生参数；5 套 EQ 仅是 *应用内* PCM 播放的尝试，不能代替硬件音效配置。已支持原音关闭 EQ。

## 编译：GitHub Actions

**方案 A（上传单个 ZIP，更接近之前的使用习惯）**

1. 在 GitHub 建立一个空仓库，例如 `S61B-SMB-Music-TV`。
2. 先在该仓库创建 `.github/workflows/android.yml`，把本源码包里同名文件的内容全部粘贴进去（GitHub 网页可用 Add file → Create new file；文件名必须含 `.github/workflows/`）。
3. 上传完整源码 ZIP（直接传 ZIP，无须解压；它必须位于仓库根目录）。
4. 进入 GitHub → Actions → Build S61B SMB Music TV APK，触发 Run workflow；每次推送源码 ZIP 到 main/master 也会自动触发。
5. 构建完成后在该 workflow 的 Artifacts 下载 `S61B-SMB-Music-TV-debug`，解压得到 `app-debug.apk`。
6. 把 APK 发到电视（Send Files to TV / ADB）安装。

**方案 B（源码解压后上传 GitHub）**

把 ZIP 解压，将里面的 `settings.gradle`、`app`、`.github` 等文件/文件夹放到仓库根目录。同一个 workflow 会自动识别源码并编译。

### 构建说明

- 使用 Android Gradle Plugin 8.7.3 + Gradle 8.9 + JDK 17。
- 依赖 Media3 1.8.1 + jCIFS-NG 2.1.10，从 Google Maven 与 Maven Central 获取。
- 目前已生成可编译工程与 CI 配置，但本交付环境没有 Android SDK，故**没有进行 APK 真机或 CI 编译验证**。
- 这是供个人局域网播放的开发版，不含线上账户或数据上传模块。

## 常见排错

- `STATUS_LOGON_FAILURE`：账号密码不对；不支持 Guest 时请填写路由器实际 SMB 用户。
- `STATUS_BAD_NETWORK_NAME`：共享名错误。根路径必须是 `smb://IP/共享名称/`，不是 `smb://IP/`。
- 连接超时：IP/端口445、设备处于不同访客网络、Wi‑Fi 隔离，或 SMB 服务未开启。
- 播放失败：格式/编码不兼容；先用 MP3、FLAC 测试，检查 NAS 读权限。
- EQ 不生效：Google TV 的数字音频链路可能绕过 Android AudioEffect；请改用 S61B 原生 Music 模式调节。
- 无封面：请在专辑文件夹放置 `folder.jpg`，当前版本不提取每首歌曲内嵌的 ID3 专辑封面。
- 暂未提供前台播放服务，离开 App 后不能保证后台持续播放。
